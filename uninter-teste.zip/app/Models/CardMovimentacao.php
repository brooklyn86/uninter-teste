<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CardMovimentacao extends Model
{
    public $table = 'card_movimentacao';
    public $timestamps = false;
}
