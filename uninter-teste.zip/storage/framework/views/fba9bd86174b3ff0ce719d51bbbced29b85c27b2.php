


<?php $__env->startSection('content'); ?>  
    <div class="container">
    <div class="panel panel-primary">
        <div class="panel-heading">Listagem de cursos</div>
            <div class="panel-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Curso</th>
                            <th scope="col">Tipo</th>
                            <th scope="col">Professores</th>
                            <th scope="col">Materiais</th>
                            <th scope="col">Ação</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($card->id_card); ?></th>
                                <td><?php echo e($card->curso); ?></td>
                                <td><?php echo e($card->tipo); ?></td>
                                <td><?php $__currentLoopData = $card->professores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $professor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($professor->nome); ?>,
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td><?php $__currentLoopData = $card->materiais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="glyphicon <?php echo e($material->icone); ?>" data-toggle="tooltip" data-placement="top" title="<?php echo e($material->material); ?>" style="margin-right: 6px"></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td>
                                    <a href="/dashboard/cadastro/card/<?php echo e($card->id_card); ?>/material" class="btn btn-info">Adicionar Materia</a>
                                    <a href="/dashboard/cadastro/card/<?php echo e($card->id_card); ?>/professor" class="btn btn-warning">Adicionar Professor</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\victo\OneDrive\Desktop\Projetos\unipe-teste\resources\views/card/list.blade.php ENDPATH**/ ?>