


<?php $__env->startSection('content'); ?>  
    <div class="container">
    <div class="panel panel-primary">
        <div class="panel-heading">Cadastro de novo curso</div>
            <div class="panel-body">
                <form method="post" action="<?php echo e(route('post.create.curso')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="name">Nome do Curso</label>
                        <input type="text" class="form-control" name="curso" id="curso" placeholder="Nome do Curso">
                    </div>
                    <button type="submit" class="btn btn-warning">Cadastrar</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\victo\OneDrive\Desktop\Projetos\unipe-teste\resources\views/cursos/create.blade.php ENDPATH**/ ?>