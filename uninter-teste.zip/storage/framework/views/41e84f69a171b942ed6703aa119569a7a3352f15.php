<?php if(session('success')): ?>
<script>
    Swal.fire({
    title: 'Done!',
    text: "<?php echo e(session('success')); ?>",
    icon: 'success',
    confirmButtonText: 'Fechar'
    })
</script>
<?php endif; ?>

<?php if(session('error')): ?>
<script>
    Swal.fire({
    title: 'Falha!',
    text: "<?php echo e(session('error')); ?>",
    icon: 'error',
    confirmButtonText: 'Fechar'
    })
</script>
<?php endif; ?>
<?php if(isset($errors) && count($errors) > 0): ?>
    <div class="alert alert-danger">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><?php echo e($error); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?><?php /**PATH C:\Users\victo\OneDrive\Desktop\Projetos\unipe-teste\resources\views/includes/alerts.blade.php ENDPATH**/ ?>