


<?php $__env->startSection('content'); ?>  
    <div class="container">
    <div class="panel panel-primary">
        <div class="panel-heading">Cadastro de novo material ao card #<?php echo e($card->id_card); ?></div>
            <div class="panel-body">
                <form method="post" action="<?php echo e(route('post.create.material.card')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="id_material">Escolha um material</label>
                        <select class="form-control js-example-basic-single" name="id_material" id="id_material">
                            <option value="">Escolha um material</option>

                            <?php $__currentLoopData = $materiais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($material->id_material); ?>"><?php echo e($material->material); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="hidden" name="id_card" value="<?php echo e($card->id_card); ?>" />
                    </div>
                    <button type="submit" class="btn btn-warning">Cadastrar</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\victo\OneDrive\Desktop\Projetos\unipe-teste\resources\views/card/add_material/index.blade.php ENDPATH**/ ?>