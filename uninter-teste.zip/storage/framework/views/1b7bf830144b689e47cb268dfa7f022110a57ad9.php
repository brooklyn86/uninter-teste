


<?php $__env->startSection('content'); ?>  
    <div class="container">
    <div class="panel panel-primary">
        <div class="panel-heading">Cadastro de novo professor ao card #<?php echo e($card->id_card); ?></div>
            <div class="panel-body">
                <form method="post" action="<?php echo e(route('post.create.professor.card')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="id_professor">Escolha um Professor</label>
                        <select class="form-control js-example-basic-single" name="id_professor" id="id_professor">
                            <option value="">Escolha um material</option>

                            <?php $__currentLoopData = $professores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $professor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($professor->id_professor); ?>"><?php echo e($professor->nome); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="hidden" name="id_card" value="<?php echo e($card->id_card); ?>" />
                    </div>
                    <button type="submit" class="btn btn-warning">Cadastrar</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\victo\OneDrive\Desktop\Projetos\unipe-teste\resources\views/card/add_professor/index.blade.php ENDPATH**/ ?>