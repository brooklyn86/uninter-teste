


<?php $__env->startSection('content'); ?>  
    <div class="container">
    <div class="panel panel-primary">
        <div class="panel-heading">Cadastro de novo Card de conteúdo</div>
            <div class="panel-body">
                <form method="post" action="<?php echo e(route('post.create.card')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="id_curso">Escolha um curso</label>
                        <select class="form-control js-example-basic-single" name="id_curso" id="id_curso">
                            <option value="">Escolha um curso</option>

                            <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($curso->id_curso); ?>"><?php echo e($curso->curso); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="id_curso">Escolha um tipo</label>
                        <select class="form-control js-example-basic-single" name="id_tipo" id="id_tipo">
                            <option value="">Escolha um tipo</option>

                            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($type->id_tipo); ?>"><?php echo e($type->tipo); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="name">Quantidade de Aulas</label>
                        <input type="number" class="form-control" name="num_aula" id="num_aula" placeholder="Quantidade de Aulas">
                    </div>
                    <button type="submit" class="btn btn-warning">Cadastrar</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\victo\OneDrive\Desktop\Projetos\unipe-teste\resources\views/card/create.blade.php ENDPATH**/ ?>